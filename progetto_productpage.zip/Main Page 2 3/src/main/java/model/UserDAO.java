package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserDAO {
    /*
        public void doSave(UserBean userDB) {
            try (Connection con = ConPool.getConnection()) {
                PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO userDB (name, surname, email, address1, address2, city, state, zip, password, country) VALUES(?,?,?,?,?,?,?,?,?,?)",
                        Statement.RETURN_GENERATED_KEYS);


                ps.setString(1, userDB.getName());
                ps.setString(2, userDB.getSurname());
                ps.setString(3, userDB.getEmail());
                ps.setString(4, userDB.getAddress1());
                ps.setString(5, userDB.getAddress2());
                ps.setString(6, userDB.getCity());
                ps.setString(7, userDB.getState());
                ps.setString(8, userDB.getZip());
                ps.setString(9, userDB.getPassword());
                ps.setString(10, userDB.getCountry());

                if (ps.executeUpdate() != 1) {
                    throw new RuntimeException("INSERT error.");
                }

                ResultSet rs = ps.getGeneratedKeys();
                rs.next();
                int id = rs.getInt(1);
                userDB.setId(id);

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }


        public UserDAO doSave() {
            return null;
        }
    }

     */
    public void doSave(UserBean user) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement("INSERT INTO userDB (Name ,Surname, Address1, Address2, City, State, Zip, Mail, Password, Country) VALUES(?,?,?,?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, user.getName());
            ps.setString(2, user.getSurname());
            ps.setString(3, user.getAddress1());
            ps.setString(4, user.getAddress2());
            ps.setString(5, user.getCity());
            ps.setString(6, user.getState());
            ps.setString(7, user.getZip());
            ps.setString(8, user.getEmail());
            ps.setString(9, user.getPassword());
            ps.setString(10, user.getCountry());
            if (ps.executeUpdate() != 1) {
                throw new RuntimeException("INSERT error.");
            }
            PreparedStatement ps1 = con.prepareStatement("INSERT INTO credentials (Mail ,Password) VALUES(?,?)", Statement.RETURN_GENERATED_KEYS);
            ps1.setString(1, user.getEmail());
            ps1.setString(2, user.getPassword());
            if (ps1.executeUpdate() != 1) {
                throw new RuntimeException("INSERT error.");
            }

            ResultSet rs = ps.getGeneratedKeys();
            rs.next();
            int id = rs.getInt(1);
            user.setId(id);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}