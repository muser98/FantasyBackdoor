package model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class loginDAO {
    public loginBean doCheck(loginBean credential) {
        loginBean l = null;
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement("select * from credentials where Mail=? and Password=?");
            ps.setString(1, credential.getEmail());
            ps.setString(2, credential.getPwd());
            ResultSet result = ps.executeQuery();
            l = null;
            if (result.next()) {
                l = new loginBean();
                l.setEmail(result.getString("Mail"));
                l.setPwd(result.getString("Password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return l;
    }
}